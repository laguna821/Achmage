# Achmage's Portfolio
laguna821의 데이터 사이언스 작업 저장소.

# [Project 1: George Floyd 관련 트윗 수집후 감성분석](https://github.com/laguna821/Achmage/tree/main/gfloyd)

<img src="https://user-images.githubusercontent.com/82581241/114874426-48ff1a80-9e37-11eb-9a39-8d9fff8d311a.jpg" width="30%"> <img src="https://user-images.githubusercontent.com/82581241/114874434-4ac8de00-9e37-11eb-8d63-a0b74b0300a5.jpg" width="30%"> <img src="https://user-images.githubusercontent.com/82581241/114874440-4dc3ce80-9e37-11eb-8915-270c58c52bbb.jpg" width="30%"> <img src="https://user-images.githubusercontent.com/82581241/114874697-8663a800-9e37-11eb-8549-6ed5d908d9d2.jpg" width="30%"> <img src="https://user-images.githubusercontent.com/82581241/114874715-8b285c00-9e37-11eb-9dc2-4098abffa6a2.jpg" width="30%"> <img src="https://user-images.githubusercontent.com/82581241/114874704-88c60200-9e37-11eb-8f22-67b5afd3ba21.jpg" width="30%">
