
# [Project 1: George Floyd 관련 트윗 수집후 감성분석]
* Python (Spyder)로 Twint 패키지를 통해서 George Floyd 관련 트윗 수집
* 검색어: George Floyd OR Minneapolis OR Minneapolis Riots OR Floyd OR Derek Chauvin OR #icantbreathe #georgefloyd OR #blcklivesmatter
* 검색기간: 2020년 5월 25일 - 30일
* 수집언어: 영어
* BING 감성사전으로 긍/부정 워드클라우드 생성
* NRC 감성사전으로 Discrete emotion wordcloud 생성
